# EventResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **string** |  | [optional] 
**id** | **string** |  | [optional] 
**action** | **string** |  | [optional] 
**user_id** | **string** |  | [optional] 
**time** | [**\DateTime**](\DateTime.md) |  | [optional] 
**task_url** | **string** |  | [optional] 
**process_instance_url** | **string** |  | [optional] 
**message** | **string[]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


