# TableMetaData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**table_name** | **string** |  | [optional] 
**column_names** | **string[]** |  | [optional] 
**column_types** | **string[]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


