# Operation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | [optional] 
**xml_row_number** | **int** |  | [optional] 
**xml_column_number** | **int** |  | [optional] 
**extension_elements** | [**map[string,\Swagger\Client\Model\ExtensionElement[]]**](array.md) |  | [optional] 
**attributes** | [**map[string,\Swagger\Client\Model\ExtensionAttribute[]]**](array.md) |  | [optional] 
**name** | **string** |  | [optional] 
**implementation_ref** | **string** |  | [optional] 
**in_message_ref** | **string** |  | [optional] 
**out_message_ref** | **string** |  | [optional] 
**error_message_ref** | **string[]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


