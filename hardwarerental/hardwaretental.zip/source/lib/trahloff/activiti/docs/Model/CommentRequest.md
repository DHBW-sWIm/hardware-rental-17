# CommentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | [optional] 
**url** | **string** |  | [optional] 
**author** | **string** |  | [optional] 
**message** | **string** |  | [optional] 
**type** | **string** |  | [optional] 
**save_process_instance_id** | **bool** |  | [optional] [default to false]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


