<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_digitalsignature';
$plugin->version = 2018090900;
$plugin->release = 'v0.0';
$plugin->requires = 2014051200;
$plugin->maturity = MATURITY_ALPHA;
$plugin->cron = 0;
$plugin->dependencies = array();
